<?php
//Arquivo de Configura��o
include("system/config.php");
//Arquivo de Inicializa��o
include("system/starter.php");